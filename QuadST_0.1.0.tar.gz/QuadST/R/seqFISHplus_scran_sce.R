#' An example of spatial transcriptome data
#'
#'
"seqFISHplus_scran_sce"
